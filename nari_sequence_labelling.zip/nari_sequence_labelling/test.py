import tensorflow as tf
from tensorflow.contrib.layers.python.layers import initializers
initializer = initializers.xavier_initializer()
targets = tf.get_variable('w', shape = [64,20], dtype = tf.float32, initializer=initializer)
targets = tf.concat([tf.cast(8*tf.ones([64, 1]), tf.int32), tf.cast(targets, tf.int32)], axis=-1)

with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    sess.run(targets)
    print (targets.shape)
    print (targets.eval())

def binary_add(a,b):
    jw = a&b  # 记录进位结果
    jg = a^b  # 对应位上的计算结果
    while jw: # 直到没有进位为止
        t_a = jg
        t_b = jw<<1
        jw = t_a & t_b
        jg = t_a ^ t_b
    print ('a+b=', jg)

binary_add(3,1)
binary_add(102,23)
binary_add(33,45)

a = 8
a = a << 1
print (a)