import random
import time

js = ['计算','算一下','算一算','我想知道','我想算一下']
#org = ['南京变','青云变','福建安兜全站','国调金华换流站','苏州变','福建水电厂']
#org = ['大卓变','无锡变','常州换流站','苏州换流站','上海变电站','厦门发电厂']
org = ['东鲍变','宝鸡变','南阳变','深圳换流站']
obj = ['电压','线路']
cnt = ['越限次数','越限时长']
cal_in = ['加','加上',
		'减','减去',
		'乘','乘上','乘以',
		'除','除去','除以']
cal_after = ['之和','总加','总和','加总',
			'之差','差值',
			'之积','乘积',
			'比值']
conjunction = ['和','与']
sentences = []

for i in range(100):
	sentence = []
	rand_num1 = random.randint(10,100)
	rand_num2 = random.randint(10,100)

	js_index = rand_num1 % len(js)
	for char in js[js_index]:
		sentence.append(char + ' O')

	org_index = rand_num1 % len(org)
	for char in range(len(org[org_index])):
		if char == 0:
			sentence.append(list(org[org_index])[char] + ' B-ORG')
		else:
			sentence.append(list(org[org_index])[char] + ' I-ORG')

	obj_index = rand_num1 % len(obj)
	for char in range(len(obj[obj_index])):
		if char == 0:
			sentence.append(list(obj[obj_index])[char] + ' B-OBJ')
		else:
			sentence.append(list(obj[obj_index])[char] + ' I-OBJ')

	cnt_index = rand_num1 % len(cnt)
	for char in range(len(cnt[cnt_index])):
		if char == 0:
			sentence.append(list(cnt[cnt_index])[char] + ' B-CNT')
		else:
			sentence.append(list(cnt[cnt_index])[char] + ' I-CNT')

	cin_index = rand_num1 % len(cal_in)
	for char in range(len(cal_in[cin_index])):
		if char == 0 :
			sentence.append(list(cal_in[cin_index])[char] + ' B-CAL')
		else:
			sentence.append(list(cal_in[cin_index])[char] + ' I-CAL')

	org_index = rand_num2 % len(org)
	for char in range(len(org[org_index])):
		if char == 0:
			sentence.append(list(org[org_index])[char] + ' B-ORG')
		else:
			sentence.append(list(org[org_index])[char] + ' I-ORG')

	obj_index = rand_num1 % len(obj)
	for char in range(len(obj[obj_index])):
		if char == 0:
			sentence.append(list(obj[obj_index])[char] + ' B-OBJ')
		else:
			sentence.append(list(obj[obj_index])[char] + ' I-OBJ')

	cnt_index = rand_num1 % len(cnt)
	for char in range(len(cnt[cnt_index])):
		if char == 0:
			sentence.append(list(cnt[cnt_index])[char] + ' B-CNT')
		else:
			sentence.append(list(cnt[cnt_index])[char] + ' I-CNT')
	sentences.append(sentence)

for i in range(100):
	sentence = []
	rand_num1 = random.randint(10,100)
	rand_num2 = random.randint(10,100)

	js_index = rand_num1 % len(js)
	for char in js[js_index]:
		sentence.append(char + ' O')

	org_index = rand_num1 % len(org)
	for char in range(len(org[org_index])):
		if char == 0:
			sentence.append(list(org[org_index])[char] + ' B-ORG')
		else:
			sentence.append(list(org[org_index])[char] + ' I-ORG')

	obj_index = rand_num1 % len(obj)
	for char in range(len(obj[obj_index])):
		if char == 0:
			sentence.append(list(obj[obj_index])[char] + ' B-OBJ')
		else:
			sentence.append(list(obj[obj_index])[char] + ' I-OBJ')

	cnt_index = rand_num1 % len(cnt)
	for char in range(len(cnt[cnt_index])):
		if char == 0:
			sentence.append(list(cnt[cnt_index])[char] + ' B-CNT')
		else:
			sentence.append(list(cnt[cnt_index])[char] + ' I-CNT')

	con_index = rand_num1 % len(conjunction)
	for char in conjunction[con_index]:
		sentence.append(char + ' O')

	org_index = rand_num2 % len(org)
	for char in range(len(org[org_index])):
		if char == 0:
			sentence.append(list(org[org_index])[char] + ' B-ORG')
		else:
			sentence.append(list(org[org_index])[char] + ' I-ORG')

	obj_index = rand_num1 % len(obj)
	for char in range(len(obj[obj_index])):
		if char == 0:
			sentence.append(list(obj[obj_index])[char] + ' B-OBJ')
		else:
			sentence.append(list(obj[obj_index])[char] + ' I-OBJ')

	cnt_index = rand_num1 % len(cnt)
	for char in range(len(cnt[cnt_index])):
		if char == 0:
			sentence.append(list(cnt[cnt_index])[char] + ' B-CNT')
		else:
			sentence.append(list(cnt[cnt_index])[char] + ' I-CNT')

	caf_index = rand_num1 % len(cal_after)
	for char in range(len(cal_after[caf_index])):
		if char == 0:
			sentence.append(list(cal_after[caf_index])[char] + ' B-CAL')
		else:
			sentence.append(list(cal_after[caf_index])[char] + ' I-CAL')
	sentences.append(sentence)
with open('nari.test', 'w', encoding = 'utf-8') as f:
	for sentence in sentences:
		for char in sentence:
			f.write(char)
			f.write('\n')
		f.write('\n')

# sentence_type1 = list(itertools.product(js,org,content,type_,cal_in, org,content,type_,))
# sentence_type2 = list(itertools.product(js,org,content,type_,conjunction,org,content,type_, cal_after))
# #sentence_type3 = list(itertools.product(js,org,content,type_,conjunction,org,content,type_, cal_after,cal_in,org,content,type_))
# print (len(sentence_type1))
# print (len(sentence_type2))
# sentences = sentence_type1 + sentence_type2
# print (len(sentences))
# with open('./data/nari_cal_corpus.txt','w',encoding='utf-8') as f:
# 	for sentence in sentences:
# 		f.write("01/m  " + "  ".join(sentence) + "  "+'\n')
# 		f.write('\n')
# random_list = []

# for i in range(10):
# 	rand1 = random.randint(10,100)
# 	rand2 = random.randint(10,100)
# 	random_list.append((rand1, rand2))
# print (random_list)

