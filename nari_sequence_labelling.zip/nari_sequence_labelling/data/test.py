import codecs

def load_sentences(path):
	'''
	Load sentences. A line must contain at least a word and its tag.
	Sentences are separated by empty lines
	'''
	sentences = []
	sentence = []
	num = 0
	for line in codecs.open(path, 'r', 'utf-8-sig'):
		#print (len(line))
		num += 1
		#line = zero_digits(line.rstrip()) if zeros else line.rstrip()
		line = line.strip()
		if not line:
			if len(sentence) > 0:
				if 'DOCSTART' not in sentence[0][0]:
					sentences.append(sentence)
				sentence = []

		else:
			if line[0] == " ":
				line = "$" + line[1:]
				word = line.split()
			else:
				word = line.split()
			assert len(word) >= 2, print(word[0])
			sentence.append(word)
	if len(sentence) > 0:
		if "DOCSTART" not in sentence[0][0]:
			sentences.append(sentence)
	return sentences
#load_sentences('example.train')
sentences = load_sentences('nari.train')
print(sentences[:2])
